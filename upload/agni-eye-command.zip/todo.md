# AGNI-EYE usability fixes

- [x] Consolidate font sizes into a shared type scale with a readable minimum for body and metadata.
- [x] Consolidate text colors into semantic tokens and remove one-off color drift.
- [x] Reduce border-radius variants to the shared radius system.
- [x] Reduce button styling variants to primary, secondary, icon, and text controls.
- [x] Increase the live-intelligence eyebrow text to a readable size.
- [x] Remove long all-caps treatment from the Live signal canvas heading.
- [x] Remove long all-caps treatment from the Classification path label.
- [x] Increase evidence-chain metadata text size and readability.
- [x] Increase footer text size and contrast.
- [x] Ensure any preview-mode interruption is edge-positioned and non-blocking.
- [x] Increase section index prominence.
- [x] Add breathing room around Recenter view.
- [x] Improve analyst queue hierarchy between IDs and location metadata.
- [x] Center the Evidence notification badge precisely.

## Direct NASA FIRMS integration

- [x] Confirm NASA FIRMS endpoint and CSV field mapping for the selected regional feed.
- [x] Add browser-side fetch with the supplied key and explicit live/loading/error states.
- [x] Map returned detections into AGNI-EYE hotspot markers and evidence details.
- [x] Add visible warning that the browser-side key is public and should be rotated before production.
- [x] Verify the integration without silently reverting to simulated telemetry.

## WCAG 2.2 AA audit remediation — verified

- [x] Fix accessible names for every icon-only and control button.
- [x] Add unique labels to navigation landmarks and dialog/drawer regions.
- [x] Remove viewport zoom restrictions and preserve user scaling.
- [x] Raise contrast for rail labels, keyboard hints, metadata, footer, breadcrumbs, and status text.
- [x] Replace gradient-only active navigation contrast with a solid semantic state.
- [x] Add visible focus indicators and keyboard-safe interaction states.
- [x] Add explicit labels or accessible names to search, filters, menus, close controls, and map controls.
- [x] Improve heading hierarchy, region semantics, and section labels.
- [x] Add live-region semantics for feed status, acknowledgement feedback, and loading/error states.
- [x] Fix non-text contrast for borders, rings, status dots, icons, and focus outlines.
- [x] Ensure mobile navigation, overlays, drawers, and dialogs are keyboard reachable and dismissible.
- [x] Ensure decorative imagery and icons are hidden from assistive technology where appropriate.
- [x] Verify all 69 audit findings with automated checks and desktop/mobile browser review.
