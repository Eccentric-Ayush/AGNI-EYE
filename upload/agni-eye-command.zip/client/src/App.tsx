/* AGNI-EYE Ember Operations: the command center is the single focused workspace. */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import Home from "./pages/Home";

export default function App() {
  return <ErrorBoundary><TooltipProvider><Toaster theme="dark" position="top-right" /><Home /></TooltipProvider></ErrorBoundary>;
}
