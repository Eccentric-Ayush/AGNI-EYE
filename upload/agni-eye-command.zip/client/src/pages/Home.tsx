/* AGNI-EYE Ember Operations: dominant signal canvas, evidence chain rail, restrained motion. */
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Activity, AlertTriangle, ArrowUpRight, Bell, Box, Check, ChevronDown,
  Crosshair, Database, FileText, Filter, Gauge, Layers3, MapPin, Menu,
  MoreHorizontal, Radio, Search, ShieldCheck, SlidersHorizontal, Sparkles,
  Target, Wifi, X, Zap,
} from "lucide-react";

const logo = "/manus-storage/agni-eye-aperture-logo_0c4c87f7.png";
const mapImage = "/manus-storage/agni-eye-orbit-thermal-map_e8a26f2b.jpg";
const terrainImage = "/manus-storage/agni-eye-infrared-terrain_c35b529b.jpg";
const sensorImage = "/manus-storage/agni-eye-sensor-field_21eac110.jpg";
const NASA_FIRMS_MAP_KEY = "524d8078636df40591a62ad5aba84bb5";
const NASA_FIRMS_ENDPOINT = `https://firms.modaps.eosdis.nasa.gov/api/area/csv/${NASA_FIRMS_MAP_KEY}/VIIRS_NOAA20_NRT/54,5.5,102,40/1`;

type FeedState = "loading" | "live" | "error";
function parseFirmsCsv(csv: string): Hotspot[] {
  const rows = csv.trim().split(/\r?\n/).slice(1).map(line => line.split(","));
  return rows.filter(row => row.length >= 14 && Number.isFinite(Number(row[0])) && Number.isFinite(Number(row[1]))).slice(0, 40).map((row, index) => {
    const latitude = Number(row[0]); const longitude = Number(row[1]); const confidence = String(row[9] || "n").toLowerCase();
    const score = confidence === "h" ? 92 : confidence === "l" ? 68 : 80;
    const severity: Hotspot["severity"] = score >= 90 ? "Critical" : score >= 78 ? "High" : "Watch";
    return { id: `NASA-${String(index + 1).padStart(3, "0")}`, name: `FIRMS detection ${index + 1}`, region: `${latitude.toFixed(2)}° N / ${longitude.toFixed(2)}° E`, score, severity, x: Math.max(8, Math.min(92, ((longitude - 54) / 48) * 100)), y: Math.max(10, Math.min(90, 100 - ((latitude - 5.5) / 34.5) * 100)), delta: `BT ${Number(row[2] || 0).toFixed(1)} K`, time: `${String(row[6] || "").padStart(4, "0")} UTC` };
  });
}

type Hotspot = { id: string; name: string; region: string; score: number; severity: "Critical" | "High" | "Watch"; x: number; y: number; delta: string; time: string; };
const hotspots: Hotspot[] = [
  { id: "HS-0427", name: "Kinnaur Ridge", region: "HP / Sector 04", score: 96, severity: "Critical", x: 69, y: 31, delta: "+18.4°C", time: "02m ago" },
  { id: "HS-0419", name: "Tawang Pass", region: "AR / Sector 11", score: 84, severity: "High", x: 49, y: 53, delta: "+11.2°C", time: "07m ago" },
  { id: "HS-0408", name: "Kutch Perimeter", region: "GJ / Sector 02", score: 68, severity: "Watch", x: 24, y: 68, delta: "+6.1°C", time: "14m ago" },
  { id: "HS-0402", name: "Siachen Shelf", region: "LA / Sector 19", score: 61, severity: "Watch", x: 40, y: 22, delta: "+4.8°C", time: "21m ago" },
];

const nav = [
  { label: "Live map", icon: Crosshair }, { label: "Analysis", icon: Activity },
  { label: "Evidence", icon: Database }, { label: "Reports", icon: FileText },
];

function Sparkline({ values, color = "#ff6a2a" }: { values: number[]; color?: string }) {
  const points = values.map((v, i) => `${(i / (values.length - 1)) * 100},${100 - v}`).join(" ");
  return <svg aria-hidden="true" focusable="false" viewBox="0 0 100 100" preserveAspectRatio="none" className="sparkline"><polyline fill="none" stroke={color} strokeWidth="3" points={points} vectorEffect="non-scaling-stroke" /></svg>;
}

function App() {
  const [activeNav, setActiveNav] = useState("Live map");
  const [selected, setSelected] = useState<Hotspot>(hotspots[0]);
  const [severity, setSeverity] = useState("All signals");
  const [search, setSearch] = useState("");
  const [acknowledged, setAcknowledged] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [showSources, setShowSources] = useState(false);
  const [showCommand, setShowCommand] = useState(false);
  const [feedState, setFeedState] = useState<FeedState>("loading");
  const [liveHotspots, setLiveHotspots] = useState<Hotspot[]>([]);
  const [feedError, setFeedError] = useState("");
  const [lastRefresh, setLastRefresh] = useState("");

  useEffect(() => {
    let cancelled = false;
    const loadNASAFeed = async () => {
      setFeedState("loading"); setFeedError("");
      try {
        const response = await fetch(NASA_FIRMS_ENDPOINT, { headers: { Accept: "text/csv" } });
        if (!response.ok) throw new Error(`NASA FIRMS responded with ${response.status}`);
        const parsed = parseFirmsCsv(await response.text());
        if (!parsed.length) throw new Error("NASA FIRMS returned no detections for this window");
        if (!cancelled) { setLiveHotspots(parsed); setSelected(parsed[0]); setFeedState("live"); setLastRefresh(new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })); }
      } catch (error) {
        if (!cancelled) { setFeedState("error"); setFeedError(error instanceof Error ? error.message : "NASA FIRMS feed unavailable"); }
      }
    };
    loadNASAFeed();
    const timer = window.setInterval(loadNASAFeed, 5 * 60 * 1000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, []);

  useEffect(() => {
    if (!mobileMenu && !showSources && !showCommand) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setMobileMenu(false); setShowSources(false); setShowCommand(false); }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [mobileMenu, showSources, showCommand]);

  const sourceHotspots = feedState === "live" ? liveHotspots : hotspots;
  const visibleHotspots = useMemo(() => sourceHotspots.filter(h => (severity === "All signals" || h.severity === severity) && `${h.name} ${h.region}`.toLowerCase().includes(search.toLowerCase())), [severity, search, sourceHotspots]);
  const selectHotspot = (hotspot: Hotspot) => { setSelected(hotspot); setAcknowledged(false); toast(`Focused ${hotspot.id}`, { description: `${hotspot.name} evidence chain is now active.` }); };
  const action = (message: string) => toast(message, { description: "Action queued in the analyst workspace." });

  return (
    <div className="command-shell">
      <aside id="agni-eye-navigation" className={`command-rail ${mobileMenu ? "open" : ""}`} aria-label="AGNI-EYE command navigation">
        <div className="rail-brand"><img src={logo} alt="Agni-Eye mark" /><div><strong>AGNI<span>-</span>EYE</strong><small>COMMAND / 01</small></div><button className="mobile-close" aria-label="Close navigation" onClick={() => setMobileMenu(false)}><X size={16}/></button></div>
        <div className="rail-status"><span className="status-pulse"/> <span>OPS ONLINE</span><b>99.98%</b></div>
        <p className="rail-label">Workspace</p>
        <nav className="rail-nav" aria-label="Workspace navigation">{nav.map(({ label, icon: Icon }) => <button key={label} aria-current={activeNav === label ? "page" : undefined} className={activeNav === label ? "active" : ""} onClick={() => { setActiveNav(label); setMobileMenu(false); }}><Icon size={17}/><span>{label}</span>{label === "Evidence" && <i>7</i>}</button>)}</nav>
        <p className="rail-label">Mission tools</p>
        <nav className="rail-nav secondary" aria-label="Mission tools navigation"><button onClick={() => setShowSources(true)}><Radio size={17}/><span>Source health</span><em className="mini-live"/></button><button onClick={() => action("Report composer opened")}><FileText size={17}/><span>Report builder</span></button><button onClick={() => setShowCommand(true)}><SlidersHorizontal size={17}/><span>Command palette</span><kbd>⌘ K</kbd></button></nav>
        <div className="rail-bottom"><div className="operator"><div className="avatar">RK</div><div><strong>R. Kashyap</strong><small>Senior analyst</small></div><ChevronDown size={14}/></div><button className="rail-settings" aria-label="Open settings" onClick={() => action("Settings are ready for configuration")}><MoreHorizontal size={18}/></button></div>
      </aside>

      <main className="workspace">
        <header className="topbar"><button className="menu-button" aria-label="Open navigation" aria-expanded={mobileMenu} aria-controls="agni-eye-navigation" onClick={() => setMobileMenu(true)}><Menu size={18}/></button><div className="crumb"><span>MISSION / 07</span><b>/</b><strong>THERMAL ANOMALY WATCH</strong></div><div className="top-actions"><div className="global-search"><Search size={15}/><input aria-label="Search signals, sites, and IDs" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search signals, sites, IDs"/><kbd>/</kbd></div><button className="top-icon" aria-label="Notifications" onClick={() => action("No new priority alerts")}><Bell size={17}/><i/></button><button className="operator-top" aria-label="Open operator menu" onClick={() => action("Operator profile opened")}><span className="avatar small">RK</span><ChevronDown size={14}/></button></div></header>

        <div className="content-scroll">
          <section className="page-intro"><div><p className="eyebrow" aria-live="polite"><span className={feedState === "live" ? "live-dot" : "status-pulse"}/> {feedState === "live" ? "NASA FIRMS / LIVE DETECTIONS" : feedState === "loading" ? "NASA FIRMS / CONNECTING" : "NASA FIRMS / FALLBACK DATA"} · {lastRefresh || "awaiting feed"}</p>{feedState === "error" && <p className="feed-warning" role="status">Live NASA feed unavailable: {feedError}. Showing local demo signals until the connection is restored.</p>}<h1>Thermal anomaly<br/><i>watch floor.</i></h1><p className="intro-copy">A focused view of heat signatures across the northern perimeter. Classify what matters, preserve the evidence chain, and move before the signal compounds.</p></div><div className="mission-meta"><div><span>MISSION WINDOW</span><b>06h 42m</b><small>until next orbital pass</small></div><div><span>MODEL BUILD</span><b>RF-2.4.1</b><small><ShieldCheck size={12}/> 94.7% calibrated</small></div><button className="outline-button" onClick={() => action("Export package prepared")}><ArrowUpRight size={15}/> Export brief</button></div></section>

          <section className="kpi-strip"><div className="kpi accent"><div className="kpi-top"><span>Priority signals</span><AlertTriangle size={16}/></div><strong>04</strong><div className="kpi-bottom"><span>+2 since 12:00</span><Sparkline values={[30,34,32,46,42,58,67,78]} /></div></div><div className="kpi"><div className="kpi-top"><span>Signals triaged</span><Check size={16}/></div><strong>128</strong><div className="kpi-bottom"><span className="green">↑ 18.6%</span><small>vs. previous window</small></div></div><div className="kpi"><div className="kpi-top"><span>Sensor coverage</span><Wifi size={16}/></div><strong>92.4<span>%</span></strong><div className="kpi-bottom"><span className="cyan">All sectors nominal</span><small>18 / 18 sources</small></div></div><div className="kpi"><div className="kpi-top"><span>Median confidence</span><Gauge size={16}/></div><strong>87<span>/100</span></strong><div className="kpi-bottom"><span className="amber">+4.2 pts</span><small>model performance</small></div></div></section>

          <section className="signal-layout">
            <div className="map-panel panel"><div className="panel-head"><div><span className="panel-index">01</span><div><h2>Live signal canvas</h2><p>Orbital thermal composite · 5 min latency</p></div></div><div className="head-tools"><button className="filter-pill" aria-label={`Filter signals, currently ${severity}`} onClick={() => setSeverity(severity === "All signals" ? "Critical" : "All signals")}><Filter size={14}/> {severity}<ChevronDown size={14}/></button><button className="square-button" aria-label="Toggle map layers" onClick={() => action("Map layers toggled")}><Layers3 size={15}/></button></div></div><div className="map-canvas" role="region" aria-label="Live NASA FIRMS thermal anomaly map" style={{ backgroundImage: `linear-gradient(90deg, rgba(7,11,16,.56), rgba(7,11,16,.08)), url(${mapImage})` }}><div className="map-grid"/><div className="map-coords top-left">34°18' N<br/>77°44' E</div><div className="map-coords bottom-right">THERMAL / IR-04<br/>ZOOM 08 · NORTH ↑</div><div className="scan-line"/>{visibleHotspots.map(h => <button key={h.id} className={`hotspot ${h.severity.toLowerCase()} ${selected.id === h.id ? "selected" : ""}`} style={{ left: `${h.x}%`, top: `${h.y}%` }} onClick={() => selectHotspot(h)} aria-label={`Select ${h.name}`}><span className="hotspot-ring"/><span className="hotspot-core"/><b>{h.score}</b></button>)}<div className="map-label label-one" aria-hidden="true"><span/> NORTHERN ARC <b>04 ACTIVE</b></div><div className="map-label label-two" aria-hidden="true"><span/> SENSOR NET / 18</div><div className="map-legend"><span><i className="legend-dot critical"/> Critical</span><span><i className="legend-dot high"/> Elevated</span><span><i className="legend-dot watch"/> Watch</span></div></div><div className="map-footer" role="status" aria-live="polite"><span><Target size={14}/> {visibleHotspots.length} visible signals</span><span><span className={feedState === "live" ? "live-dot" : "status-pulse"}/> {feedState === "live" ? "NASA stream connected" : feedState === "loading" ? "NASA stream connecting" : "NASA stream unavailable"}</span><button onClick={() => action("Map centered on northern perimeter")}>Recenter view <ArrowUpRight size={13}/></button></div></div>

            <aside className="evidence-panel panel"><div className="panel-head evidence-head"><div><span className="panel-index">02</span><div><h2>Evidence chain</h2><p>Selected signal / {selected.id}</p></div></div><button className="square-button" aria-label="Toggle evidence layers" onClick={() => action("Evidence layers toggled")}><MoreHorizontal size={16}/></button></div><div className="selected-signal"><div className="signal-title"><div><span className={`severity-tag ${selected.severity.toLowerCase()}`}>{selected.severity}</span><h3>{selected.name}</h3><p><MapPin size={13}/> {selected.region}</p></div><div className="confidence-ring"><strong>{selected.score}</strong><span>CONF</span></div></div><div className="signal-stats"><div><span>BRIGHTNESS TEMP</span><b>{selected.delta}</b></div><div><span>LAST SEEN</span><b>{selected.time}</b></div></div><button className="primary-button" aria-pressed={acknowledged} onClick={() => { setAcknowledged(true); action("Signal acknowledged"); }}>{acknowledged ? <><Check size={15}/> Acknowledged</> : <><Zap size={15}/> Acknowledge signal</>}</button></div><div className="chain"><div className="chain-label"><span>Classification path</span><b>96.2% stable</b></div>{[{ icon: Radio, title: "Detection event", detail: "Satellite IR-04 · 14:24:02", state: "verified" }, { icon: Sparkles, title: "Model classification", detail: "Industrial heat / RF-2.4.1", state: "verified" }, { icon: ShieldCheck, title: "Analyst disposition", detail: acknowledged ? "Signal acknowledged · R. Kashyap" : "Awaiting analyst action", state: acknowledged ? "verified" : "pending" }].map(({ icon: Icon, title, detail, state }, i) => <div className="chain-item" key={title}><div className={`chain-icon ${state}`}><Icon size={14}/></div><div><b>{title}</b><span>{detail}</span></div>{i < 2 && <div className="chain-line"/>}</div>)}</div><div className="evidence-thumb" style={{ backgroundImage: `url(${sensorImage})` }}><div><span>RAW FRAME / IR-04</span><b>Open source imagery <ArrowUpRight size={13}/></b></div></div></aside>
          </section>

          <section className="lower-grid"><div className="panel trend-panel"><div className="panel-head"><div><span className="panel-index">03</span><div><h2>Signal velocity</h2><p>Detections by 30-minute window</p></div></div><button className="filter-pill">Last 6 hours <ChevronDown size={14}/></button></div><div className="trend-body"><div className="trend-number"><strong>+31.8%</strong><span>anomaly volume</span><b><ArrowUpRight size={13}/> 12.4% against baseline</b></div><div className="trend-chart"><div className="chart-lines"><i/><i/><i/><i/></div><Sparkline values={[22,30,27,36,33,43,39,51,48,62,56,69,65,82,77,94]} color="#ff6a2a"/><div className="chart-axis"><span>08:00</span><span>10:00</span><span>12:00</span><span>14:00</span></div></div></div></div><div className="panel queue-panel"><div className="panel-head"><div><span className="panel-index">04</span><div><h2>Analyst queue</h2><p>Prioritized by confidence × impact</p></div></div><button className="text-button" onClick={() => setActiveNav("Evidence")}>View all <ArrowUpRight size={13}/></button></div><div className="queue-list">{sourceHotspots.slice(0, 3).map(h => <button className="queue-row" key={h.id} onClick={() => selectHotspot(h)}><span className={`queue-severity ${h.severity.toLowerCase()}`}/><span className="queue-main"><b>{h.id} · {h.name}</b><small>{h.region}</small></span><strong>{h.score}<small>CONF</small></strong><ArrowUpRight size={14}/></button>)}</div></div></section>
          <footer className="workspace-footer"><span>AGNI-EYE / NTRO intelligence system</span><span>Classification: internal · {feedState === "live" ? "NASA FIRMS live telemetry" : "local fallback telemetry"}</span><span>Build 2.4.1 <span className="mini-live"/></span></footer>
        </div>
      </main>

      {showSources && <div className="overlay" role="presentation" onClick={() => setShowSources(false)}><div className="drawer" role="dialog" aria-modal="true" aria-labelledby="source-health-title" onClick={e => e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">MISSION TOOLS</span><h2 id="source-health-title">Source health</h2></div><button className="square-button" aria-label="Close source health" onClick={() => setShowSources(false)}><X size={16}/></button></div><p className="drawer-copy">Telemetry provenance across active orbital and ground sources.</p>{["IR-04 / Polar pass", "THERMAL-NET / North arc", "SENTINEL EDGE / Kinnaur"].map((s, i) => <div className="source-row" key={s}><div className="source-icon"><Radio size={15}/></div><div><b>{s}</b><span>{i === 0 ? "5 min latency · 99.98%" : "12 min latency · 98.4%"}</span></div><i className="source-ok"/></div>)}</div></div>}
      {showCommand && <div className="overlay" role="presentation" onClick={() => setShowCommand(false)}><div className="command-modal" role="dialog" aria-modal="true" aria-labelledby="command-palette-title" onClick={e => e.stopPropagation()}><h2 id="command-palette-title" className="sr-only">Command palette</h2><div className="global-search modal-search"><Search size={16}/><input aria-label="Search commands" autoFocus placeholder="Jump to a command…"/><kbd>ESC</kbd></div>{["Open live signal canvas", "Generate mission brief", "Toggle sensor layers", "Review critical queue"].map((x, i) => <button key={x} onClick={() => { action(`${x} selected`); setShowCommand(false); }}><span>{i + 1}</span>{x}<ArrowUpRight size={14}/></button>)}</div></div>}
    </div>
  );
}
export default App;
