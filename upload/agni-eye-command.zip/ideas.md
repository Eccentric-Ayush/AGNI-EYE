# AGNI-EYE Command — Design Direction

## Three stylistic approaches

### Theme Name: Ember Operations
Very Brief Intro: A dark, high-contrast mission-control interface with restrained ember accents and data-dense panels. It feels operational, precise, and built for analysts who need signal over spectacle.
Probability: 0.07

### Theme Name: Monsoon Cartography
Very Brief Intro: A cool slate-and-teal geospatial workspace inspired by topographic maps, field notebooks, and satellite overlays. It creates a calmer, more investigative tone for long analysis sessions.
Probability: 0.03

### Theme Name: Signal Archive
Very Brief Intro: A warm paper-and-ink intelligence archive with redacted callouts, annotated evidence cards, and editorial hierarchy. It makes anomaly review feel like forensic research rather than generic analytics.
Probability: 0.09

## Selected approach: Ember Operations

### Design Movement
Contemporary mission-control brutalism, softened with editorial typography and tactile telemetry surfaces.

### Core Principles
1. Make the anomaly the protagonist: spatial signal, severity, confidence, and provenance must be legible immediately.
2. Use asymmetry to create analyst focus: a dominant live map, a narrow evidence rail, and an expandable command layer.
3. Treat operational status as visual material: pulse, scanlines, telemetry ticks, and system logs should feel purposeful rather than decorative.
4. Create hierarchy through contrast and density, not through excessive cards or rounded containers.

### Color Philosophy
The base is near-black graphite to preserve attention during long monitoring sessions. Ember orange marks human-priority heat and action, while a restrained blue-green indicates machine health, data confidence, and active streams. Rust red is reserved for escalation. Color is semantic and sparse: no accent appears without an operational meaning.

### Layout Paradigm
A persistent left command spine anchors the product. The main workspace uses an asymmetric split: a large live operational canvas, a stacked evidence rail, and a lower telemetry band. Content reflows into a single scrollable workspace on small screens without losing the command spine's hierarchy.

### Signature Elements
- Angular telemetry brackets and hairline rules that frame important readouts.
- Heat-map contour rings and scanline overlays to make spatial analysis feel alive.
- An "evidence chain" rail that connects detection, classification, and analyst action.

### Interaction Philosophy
Every click should either focus a signal, reveal provenance, or create an explicit next action. Hovering a hotspot reveals context; selecting it opens evidence; acknowledging it changes its operational state. Avoid decorative interaction that does not improve analysis.

### Animation
Use short, high-confidence transitions: 160–220ms for panels, 1.6s pulses for live markers, and staggered 40ms reveals for evidence rows. Animate opacity and transform only. Keep telemetry motion subtle and pause non-essential movement when reduced-motion is requested.

### Typography System
Use Space Grotesk for headings and numeric readouts, IBM Plex Sans for interface labels, and IBM Plex Mono for coordinates, timestamps, and pipeline logs. Headings are compact and assertive; body copy is calm and readable; monospaced text establishes provenance.

### Brand Essence
AGNI-EYE is an analyst-first command layer for turning thermal anomalies into defensible intelligence before they become incidents. Personality: vigilant, exacting, composed.

### Brand Voice
Headlines are terse and operational. CTAs describe the decision they enable, never generic progress language.
Example lines: “Track the heat before it becomes an incident.” “Open the evidence chain.”

### Wordmark & Logo
Use a compact eye-shaped aperture formed from two angular brackets and a central ember point. The mark must read as both a sensor aperture and a watchful eye without relying on text.

### Signature Brand Color
Ember Signal — #FF6A2A. It is warm enough to communicate thermal energy but bright and controlled enough to remain legible against graphite surfaces.

## Product upgrades from the supplied prototype

The rebuilt interface will retain the original AGNI-EYE concepts—live map, hotspot classification, reports, persistent sources, and pipeline console—while advancing them with a persistent command spine, mission summary, animated telemetry, richer hotspot evidence, severity filters, an analyst queue, source health, trend visualizations, alert acknowledgement, and responsive layouts. The first version remains frontend-only and uses clearly labeled simulated telemetry so the experience is immediately usable without backend credentials.

## Style reminder
Does this choice reinforce or dilute our design philosophy? If a UI element does not improve signal clarity, provenance, or next action, remove or subordinate it.

## Style Decisions

- The first viewport prioritizes the live operational canvas and evidence chain over large marketing-style hero space.
- The AGNI-EYE aperture mark recurs through panel corner brackets, focused signal rings, and evidence framing.
- Ember Signal `#FF6A2A` remains reserved for heat priority and analyst action; blue-green remains reserved for system health/confidence and streams.
- The evidence chain is treated as a connected forensic rail with linked nodes, timestamps, provenance, and explicit analyst disposition.
